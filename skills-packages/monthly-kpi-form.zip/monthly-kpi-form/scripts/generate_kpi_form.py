# -*- coding: utf-8 -*-
"""
generate_kpi_form.py — 月度绩效考核表 + 月报 生成器（系统开发组 / 月绩效考核模板2026.xlsx）

用法:
  python generate_kpi_form.py --month 8 [--year 2026] \
      [--ws "D:/workspace/mine/2026月度考核"] \
      [--tpl "月绩效考核模板2026.xlsx"]

产出:
  1) <ws>/<YEAR>年<MONTH>月绩效考核表.xlsx   （KPI 分值合计=80，样式与模板一致，黑字白底）
  2) <ws>/<MONTH>月月报.txt                   （按站点分类、跨天同任务合并、去站点前缀、时间正序）

要点（已踩 5 轮反馈，务必保留）:
- openpyxl load_workbook + save，原样保留合并/列宽/配色；不新建 workbook。
- 复制第 5 行示例样式后，强制 Font(color='FF000000') + fill=None，消除模板 theme 0 灰字。
- KPI 分值合计必须=80（模板 L10=SUM(G5:G10)）；KCI 量表(2/4/6/8/10)/加分项 H18/上级评分 I 列/合计公式 一律不动。
- 月报分类顺序固定；站点关键词不带"站"字也命中；合并按"页面/项目对象"(subject_of/PAGE_RE)，不加日期注释。

换月只需改下面的 kpi 字典与 --month；解析/分类/合并/样式逻辑通用。
"""

import argparse
import os
import re
import sys
from copy import copy

import openpyxl
from openpyxl.styles import Alignment, Font, PatternFill


# =================== 路径与参数 ===================
def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument("--month", type=int, required=True, help="月份数字，如 8")
    ap.add_argument("--year", type=int, default=2026, help="年份，默认 2026")
    ap.add_argument("--ws",
                    default=r"D:\workspace\mine\2026月度考核",
                    help="工作目录（含工作记录与模板）")
    ap.add_argument("--tpl", default="月绩效考核模板2026.xlsx",
                    help="模板文件名（位于 --ws 下）")
    return ap.parse_args()


# =================== 1) 解析工作记录 ===================
DATE_PAT = re.compile(r'^(\d{8})$')
ITEM_PAT = re.compile(r'^\d+[、.．]\s*(.*)$')


def parse_records(rec_path):
    tasks = []  # (date_str, raw_text)
    cur = None
    with open(rec_path, encoding='utf-8') as f:
        for line in f:
            s = line.strip()
            if not s:
                continue
            m = DATE_PAT.match(s)
            if m:
                cur = m.group(1)
                continue
            it = ITEM_PAT.match(s)
            if it and cur:
                tasks.append((cur, it.group(1)))
    return tasks


# =================== 2) 月报：分类 / 去前缀 / 合并 / 排序 ===================
CAT_ORDER = ['伊莱瑞特中文站', '伊莱瑞特英文站', '普诺赛中文站',
             '普诺赛英文站', 'EDM', '会议', '其他']

SITE_PREFIX = re.compile(
    r'^(伊莱瑞特中文站|伊莱瑞特英文站|普诺赛中文站|普诺赛英文站|'
    r'伊莱瑞特中文|伊莱瑞特英文|普诺赛中文|普诺赛英文)[的]?')
PAGE_RE = re.compile(
    r'^(.*?(?:治疗页面|落地页|活动详情页|详情页|小程序操作视频|册子落地页|页面))')


def classify(text):
    if 'EDM' in text:
        return 'EDM'
    if '会议' in text:
        return '会议'
    # 注意：关键词不带"站"字也要命中（如"伊莱瑞特中文活动详情页"）
    if '伊莱瑞特中文' in text:
        return '伊莱瑞特中文站'
    if '伊莱瑞特英文' in text:
        return '伊莱瑞特英文站'
    if '普诺赛中文' in text:
        return '普诺赛中文站'
    if '普诺赛英文' in text:
        return '普诺赛英文站'
    return '其他'


def strip_site(text):
    return SITE_PREFIX.sub('', text)


def norm(text):
    # 仅剥离跨日进度尾巴，保留有信息量的内容
    t = text
    t = re.sub(r'，?处理剩余\s*\d+\s*条', '', t)
    t = re.sub(r'，?已处理\s*\d+\s*条', '', t)
    t = re.sub(r'共\s*\d+\s*个区块[，,]', '', t)
    return t.strip()


def subject_of(text):
    # 按"页面/项目对象"归并跨天同任务
    m = PAGE_RE.match(text)
    if m:
        return m.group(1)
    if '海报生成工具' in text:
        return '海报生成工具'
    if any(k in text for k in ('工具链', 'husky', 'eslint', 'stylelint',
                               'commitlint', '规范约束', '自动化工具')):
        return '工程化工具链'
    return None


def merge_texts(texts):
    uniq = list(dict.fromkeys(texts))
    if len(uniq) == 1:
        return uniq[0]
    lcp = os.path.commonprefix(uniq)
    if lcp:
        return lcp + "；".join(t[len(lcp):] for t in uniq)
    return "；".join(uniq)


def merge_bucket(items):
    # items: (date, st) 文件顺序；按对象归并跨天同任务，不附加日期注释
    groups = {}
    for d, st in items:
        key = subject_of(st) or ("u::" + st)
        groups.setdefault(key, []).append((d, st))
    merged = []
    for key, lst in groups.items():
        lst.sort(key=lambda x: x[0])
        if key.startswith('u::') or len(lst) == 1:
            for d, st in lst:
                merged.append((d, st))
        else:
            texts = [norm(st) for _, st in lst]
            merged.append((lst[0][0], merge_texts(texts)))
    merged.sort(key=lambda x: x[0])
    return merged


CN = ['一', '二', '三', '四', '五', '六', '七']


def build_report(tasks):
    buckets = {c: [] for c in CAT_ORDER}
    for d, txt in tasks:
        buckets[classify(txt)].append((d, strip_site(txt)))
    lines = []
    present_idx = 0
    for c in CAT_ORDER:
        items = buckets[c]
        if not items:
            continue
        present_idx += 1
        merged = merge_bucket(items)
        lines.append(f"{CN[present_idx - 1]}、{c}：")
        for i, (d, text) in enumerate(merged, 1):
            lines.append(f"{i}、{text}")
        lines.append("")
    return "\n".join(lines).strip() + "\n"


# =================== 3) 绩效考核表：样式复制 + 落盘 ===================
# 每月人工给定：3 重点任务(行5-7) + 3 日常(行8-10)，G 分值合计必须=80
# 字段：D=任务名, E=任务及目标(简洁), F=完成结果, G=分值, H=自评
def build_kpi(month):
    # 8 月（示例，换月时整体改写）
    # 写法约定：E/F 每行"至少 3 条"、用"1、2、3"序号标明，可多于 3 条；
    # 但新增条目必须有意义、不重复、不啰嗦（信息量参考 7 月版，不写方块、不可过简）。
    # E=任务及目标（范畴/要做到什么），F=完成结果（量化成果）。
    return {
        5: {"D": "海报生成工具开发",
            "E": "1、从零搭建海报生成工具，打通\"需求→切图→表单→模板页\"完整链路\n"
                 "2、对接知了窝接口与 AI 调用逻辑，实现海报自动生成能力\n"
                 "3、完成模板页（8 个区块）与表单页交互逻辑开发，支撑工具联调上线",
            "F": "1、需求定稿，工具整体框架与页面结构全部落地\n"
                 "2、模板页 8 个区块与表单页交互逻辑开发完成，可正常预览与编辑\n"
                 "3、知了窝接口与 AI 调用打通，工具进入联调运行阶段",
            "G": 20, "H": 18},
        6: {"D": "伊莱瑞特中英文站重点页面开发",
            "E": "1、完成中文站干细胞治疗、免疫细胞治疗全量 tab 页面（含吸顶与切换滚动）\n"
                 "2、开发伊莱瑞特中英文站细胞状态与代谢检测试剂盒落地页\n"
                 "3、实现 Flow Cytometry 与资源栏目多页面内搜索与交互调整",
            "F": "1、干细胞/免疫细胞治疗全部 tab 页面上线，吸顶与切换交互符合预期\n"
                 "2、中英文试剂盒落地页开发完成，页面内容与样式对齐设计\n"
                 "3、多页面页内搜索与交互逻辑调整到位，信息检索体验提升",
            "G": 16, "H": 15},
        7: {"D": "前端工程化与自动化工具链建设",
            "E": "1、引入 husky/eslint/stylelint/commitlint，建立提交前强制规范校验\n"
                 "2、清理四站点冗余静态资源，统一前端工程规范\n"
                 "3、完善并同步自动化工具链，提升多站点协同开发效率",
            "F": "1、提交前自动校验（格式/规范）生效，代码风格统一\n"
                 "2、四站点静态资源清理完成，体积与加载性能改善\n"
                 "3、工具链规则完善并同步其余三站点，团队复用一致",
            "G": 14, "H": 13},
        8: {"D": "视频内容处理与站点零散优化",
            "E": "1、爬取并转码 5 个视频页面，完成 64 条视频关键词提取\n"
                 "2、重写产品详情页 gallery 模块，优化图文展示效果\n"
                 "3、修复多处页面问题：轮播图、导航、文案、链接、SEO 等",
            "F": "1、64 条视频转码与关键词提取完成，内容可用于站点分发\n"
                 "2、产品详情页 gallery 重写上线，展示效果与性能提升\n"
                 "3、轮播/导航/文案/链接/SEO 等问题修复，页面质量改善",
            "G": 15, "H": 14},
        9: {"D": "EDM 邮件制作与优化",
            "E": "1、按时完成多封营销 EDM 制作（文献、Webinar、促销、册子等）\n"
                 "2、持续优化 EDM 模板与文案，提升打开率与转化\n"
                 "3、完善邮件链接与符号，确保各推广节点正常发送",
            "F": "1、文献/Webinar/促销/册子推广等多封 EDM 按期交付\n"
                 "2、模板与文案迭代优化，复用度与制作效率提升\n"
                 "3、链接、符号修正到位，满足各推广节点发送要求",
            "G": 10, "H": 9},
        10: {"D": "站点日常运营与支持",
            "E": "1、完成 ELISA 小程序操作视频发布与册子落地页需求\n"
                 "2、支撑开学大促内容制作与按时上线\n"
                 "3、响应多站点零散文案与样式修改需求",
            "F": "1、ELISA 小程序视频发布、册子落地页需求落地\n"
                 "2、开学大促内容制作完成并按时上线\n"
                 "3、多站点零散页面文案/样式修改完成，支持运营节奏",
            "G": 5, "H": 5},
    }


def copy_style(src, dst):
    dst.font = copy(src.font)
    dst.border = copy(src.border)
    dst.fill = copy(src.fill)
    dst.alignment = copy(src.alignment)
    dst.number_format = src.number_format
    dst.protection = copy(src.protection)


def cjk_len(s):
    """估算字符串在等宽近似下的"显示宽度"：CJK 计 1，ASCII 计 0.5。"""
    n = 0.0
    for ch in s:
        n += 0.5 if ord(ch) < 0x2E80 else 1.0
    return n


def est_lines(text, col_width):
    """按列宽估算单元格换行后的行数（含 \n 硬换行）。"""
    if not text:
        return 1
    # 保守估计：CJK 约占 2.2 个宽单位，确保不低估导致裁切
    per_line = max(6, int(col_width / 2.2))
    total = 0
    for seg in str(text).split("\n"):
        total += max(1, -(-int(cjk_len(seg)) // per_line))  # ceil
    return total


def generate_xlsx(tpl_path, out_path, year, month, kpi):
    wb = openpyxl.load_workbook(tpl_path)
    ws = wb["Sheet1"]

    ref = {col: ws[f"{col}5"] for col in ("D", "E", "F", "G", "H")}
    widths = {c: ws.column_dimensions[c].width or 20 for c in ("D", "E", "F")}
    for r in range(5, 11):
        for col in ("D", "E", "F", "G", "H"):
            cell = ws[f"{col}{r}"]
            copy_style(ref[col], cell)
            # 强制黑字 + 无填充，消除模板示例行 theme 0 灰字
            cell.font = Font(name=ref[col].font.name, sz=ref[col].font.sz,
                             b=ref[col].font.bold, color='FF000000')
            cell.fill = PatternFill(fill_type=None)
            if col in ("D", "E", "F"):
                cell.alignment = Alignment(wrap_text=True, vertical="top")
            ws[f"{col}{r}"] = kpi[r][col]
        # 自动行高：取 E/F/D 中行数最多者，留出边距，确保多行内容完整显示
        nlines = max(est_lines(kpi[r]["E"], widths["E"]),
                     est_lines(kpi[r]["F"], widths["F"]),
                     est_lines(kpi[r]["D"], widths["D"]))
        ws.row_dimensions[r].height = min(140, max(30, nlines * 16 + 8))

    ws["A1"] = "系统开发组绩效考核表（%d年%d月）" % (year, month)
    base_a2 = ws["A2"].value
    if isinstance(base_a2, str) and base_a2.endswith("考核周期："):
        days = 31  # 简化：默认月末 31，如需精确可用 calendar.monthrange
        ws["A2"] = base_a2 + "%d年%d月1日 - %d年%d月%d日" % (
            year, month, year, month, days)

    wb.save(out_path)

    # 回读校验
    wb2 = openpyxl.load_workbook(out_path)
    ws2 = wb2["Sheet1"]
    g_sum = sum(ws2.cell(row=r, column=7).value for r in range(5, 11))
    h_sum = sum(ws2.cell(row=r, column=8).value for r in range(5, 11))
    print(f"KPI 表已写: {out_path}")
    print(f"KPI 分值合计 = {g_sum} (约束=80) | KPI 自评合计 = {h_sum}")
    print(f"合计公式 H19 = {ws2['H19'].value} | I19 = {ws2['I19'].value}")
    assert g_sum == 80, "KPI 分值合计必须等于 80！"
    print("校验通过。")


def main():
    args = parse_args()
    ws = args.ws
    rec = os.path.join(ws, f"{args.month}月工作记录.txt")
    tpl = os.path.join(ws, args.tpl)
    kpi_out = os.path.join(ws, f"{args.year}年{args.month}月绩效考核表.xlsx")
    report_out = os.path.join(ws, f"{args.month}月月报.txt")

    tasks = parse_records(rec)

    # 月报
    report = build_report(tasks)
    with open(report_out, 'w', encoding='utf-8') as f:
        f.write(report)
    print("===== 月报预览 =====")
    print(report)
    print(f"===== 月报已写: {report_out} =====\n")

    # 绩效考核表
    kpi = build_kpi(args.month)
    generate_xlsx(tpl, kpi_out, args.year, args.month, kpi)


if __name__ == "__main__":
    main()
