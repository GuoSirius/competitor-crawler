#!/usr/bin/env node
/*
 * check-links.js —— 校验目录树内所有 Markdown 的**相对链接**（可选：锚点）是否有效。
 *
 * 用途：文档重构（拆分 / 搬移 / 重命名 / **章节重新编号**）之后，最容易留下一堆 404。
 * 本脚本零依赖（仅 Node 内置），可在任何仓库根直接跑。
 *
 * 用法：
 *   node check-links.js                    # 以当前目录为根，只校验文件是否存在
 *   node check-links.js <dir>              # 指定根目录
 *   node check-links.js <dir> --anchors    # 同时校验 `文件.md#锚点` 与纯锚点 `#x`
 *   node check-links.js <dir> --json       # 输出 JSON（便于 CI 消费）
 *
 * 退出码：全部有效 = 0；存在失效链接 = 1（可直接当 CI 门禁）。
 *
 * 有意跳过的：外部链接（http/https）、mailto/tel/data。
 *
 * 锚点算法（★ 已实测对齐 GitHub，别再凭印象写）：
 *   1. 去掉行首 `#`，取标题文本；去掉结尾的闭合 `###`；去首尾空白；
 *   2. 转小写；
 *   3. 删除所有标点/符号（保留字母、数字、中日韩文字与**空格**）；
 *   4. **每个空格替换为一个 `-`（不折叠！）** —— 标题里的 ` · ` 会变成 `--`。
 *   5. 同名标题第 2 次出现追加 `-1`、第 3 次 `-2`……
 *   例：`## 10.4 gen-site:template · 批量生成 Excel 模板`
 *       → `104-gen-sitetemplate--批量生成-excel-模板`
 */

'use strict';

const fs = require('fs');
const path = require('path');

const SKIP_DIRS = new Set([
  'node_modules', '.git', '.wrangler', 'dist', 'build', 'out',
  'coverage', '.next', '.nuxt', '.output', '.workbuddy', '.cache',
]);

const args = process.argv.slice(2);
const asJson = args.includes('--json');
const checkAnchors = args.includes('--anchors');
const ROOT = path.resolve(args.find((a) => !a.startsWith('--')) || process.cwd());

// ---------------------------------------------------------------- slug

/** 标点/符号：ASCII 标点 + 常见中文/排版符号 + Unicode 标点区。注意**不含空格**。 */
const PUNCT =
  /[\\'!"#$%&()*+,./:;<=>?@[\]^`{|}~·—–。，、；：！？（）《》「」『』【】…“”‘’\u2000-\u206f\u2e00-\u2e7f]/g;

function slug(text) {
  return text
    .trim()
    .replace(/\s+#+\s*$/, '') // 去掉结尾闭合 ###
    .toLowerCase()
    .replace(PUNCT, '')
    .replace(/ /g, '-'); // ← 每个空格 → 一个 '-'，不折叠
}

/** 收集一个 md 文件里所有可用锚点（标题 + 显式 HTML 锚点），含重名后缀。 */
function collectAnchors(text) {
  const anchors = new Set();
  const seen = new Map();
  let inFence = false;
  for (const line of text.split(/\r?\n/)) {
    if (/^\s*(```|~~~)/.test(line)) {
      inFence = !inFence;
      continue;
    }
    if (inFence) continue;
    const m = /^#{1,6}\s+(.*)$/.exec(line);
    if (m) {
      const base = slug(m[1]);
      const n = seen.get(base) ?? 0;
      seen.set(base, n + 1);
      anchors.add(n === 0 ? base : `${base}-${n}`);
      continue;
    }
    for (const a of line.matchAll(/<a\s[^>]*(?:id|name)=["']([^"']+)["']/gi)) {
      anchors.add(a[1].toLowerCase());
    }
  }
  // 便于容忍「文档里写了 -1 但实际只有一条」这类笔误：保留 base 集合
  return { anchors, bases: new Set(seen.keys()) };
}

// ---------------------------------------------------------------- walk

function walk(dir, out = []) {
  let entries;
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true });
  } catch {
    return out;
  }
  for (const e of entries) {
    if (SKIP_DIRS.has(e.name)) continue;
    const p = path.join(dir, e.name);
    if (e.isDirectory()) walk(p, out);
    else if (e.isFile() && /\.(md|markdown)$/i.test(e.name)) out.push(p);
  }
  return out;
}

const files = walk(ROOT);
const broken = [];
let checked = 0;
let anchorsChecked = 0;

/** 缓存各 md 的锚点表，避免重复读盘 */
const anchorCache = new Map();
function anchorsOf(absPath) {
  if (!anchorCache.has(absPath)) {
    let text = '';
    try {
      text = fs.readFileSync(absPath, 'utf8');
    } catch {
      /* 读不到就当成无锚点 */
    }
    anchorCache.set(absPath, collectAnchors(text));
  }
  return anchorCache.get(absPath);
}

for (const file of files) {
  const text = fs.readFileSync(file, 'utf8');
  for (const m of text.matchAll(/\]\(\s*([^)\s]+?)\s*\)/g)) {
    const raw = m[1];
    if (/^(https?:|mailto:|tel:|data:)/i.test(raw)) continue;

    const hash = raw.indexOf('#');
    let target = hash >= 0 ? raw.slice(0, hash) : raw;
    const anchor = hash >= 0 ? raw.slice(hash + 1) : '';

    const decode = (s) => {
      try {
        return decodeURIComponent(s);
      } catch {
        return s;
      }
    };
    target = decode(target).replace(/^<|>$/g, '');

    // 纯锚点：只在本文件内校验
    let resolved;
    if (!target) {
      checked++;
      if (checkAnchors && anchor) {
        anchorsChecked++;
        const { anchors, bases } = anchorsOf(file);
        if (!anchors.has(decode(anchor).toLowerCase()) && !bases.has(decode(anchor).toLowerCase())) {
          broken.push({ file: path.relative(ROOT, file), target: raw, kind: 'anchor' });
        }
      }
      continue;
    }

    checked++;
    resolved = path.resolve(path.dirname(file), target);
    if (!fs.existsSync(resolved)) {
      broken.push({ file: path.relative(ROOT, file), target: raw, kind: 'file' });
      continue;
    }

    // `文件.md#锚点`：目标必须是 md 才谈得上锚点
    if (checkAnchors && anchor && /\.(md|markdown)$/i.test(resolved)) {
      anchorsChecked++;
      const { anchors, bases } = anchorsOf(resolved);
      const want = decode(anchor).toLowerCase();
      if (!anchors.has(want) && !bases.has(want)) {
        broken.push({ file: path.relative(ROOT, file), target: raw, kind: 'anchor' });
      }
    }
  }
}

if (asJson) {
  console.log(JSON.stringify({ root: ROOT, mdFiles: files.length, checked, anchorsChecked, broken }, null, 2));
} else {
  for (const b of broken) console.log(`BROKEN[${b.kind}]  ${b.file}  ->  ${b.target}`);
  console.log(
    `\nchecked=${checked}  anchors_checked=${anchorsChecked}  broken=${broken.length}  md_files=${files.length}`,
  );
  if (!checkAnchors) console.log('提示：加 --anchors 可同时校验「章节重新编号」导致的锚点失效。');
}
process.exit(broken.length ? 1 : 0);
