---
name: release-and-ship
description: "JS/TS 项目的「交付与发布」总技能：提交规范（commitlint/Conventional Commits）、自动 CHANGELOG（changelogen）、版本 bump（含 monorepo 多包）、交互式 release 脚本、husky 钩子与 `.git/cph` 兜底、npm 包发布（CI + NPM_TOKEN + provenance）、Web 产品上线（Cloudflare Workers/D1/Pages 同源 `/api` + Supabase）、GitHub Actions CI 与定时任务、以及静态 PWA 升级为 Tauri v2 桌面壳（含签名与应用内自动更新）。Use when setting up commit conventions or CHANGELOG, building/fixing an interactive `npm run release`, publishing a package, shipping a web product (deploy/CI/cron), packaging a static PWA as a desktop app, or debugging: wrong/English CHANGELOG groupings, a broken `## ...main` version header, a release that only prints and never writes, `git commit` dying with `/usr/bin/env: 'sh': No such file or directory`, a deploy silently serving a stale bundle, a scheduled job running at the wrong hour, D1 `IN (...)` throwing, `subject must be lower-case`, or `type must be one of [...]`."
agent_created: true
version: "1.0.0"
display_name: "交付与发布（提交规范 · CHANGELOG · 上线 · 桌面端）"
display_name_en: "Release & Ship (commits · changelog · deploy · desktop)"
description_zh: "JS/TS 项目的交付与发布总技能：commitlint 约定式提交、changelogen 自动 CHANGELOG、版本 bump（含 monorepo）、交互式 release 脚本、husky 与 .git/cph 兜底、npm 包发布（CI+Secrets）、Cloudflare+Supabase Web 上线（同源 /api、D1、cron 时区）、静态 PWA 转 Tauri 桌面壳（签名+应用内自动更新）。含全部踩坑清单与可复制模板。"
description_en: "One-stop release & ship skill for JS/TS projects: commitlint + auto CHANGELOG + version bump (incl. monorepo) + interactive release script + husky/`.git/cph` fallback + npm publishing via CI + Cloudflare/Supabase web shipping + static-PWA-to-Tauri desktop packaging with signed auto-update."
---

# 交付与发布（Release & Ship）

> **本技能是「把东西交付出去」的唯一入口**：从一个提交信息该写什么，一直到桌面安装包怎么签名自动更新。
> 主干只放**跨场景通用**的规则与坑；每个场景的实现细节在 `references/`，**按需读，不要一次全读**。

## 何时使用

| 场景 | 典型话术 |
|---|---|
| 配提交规范 / 修 CHANGELOG | 「配置 commitlint」「CHANGELOG 分组是英文的」「版本头变成 `## v1.0.0...main`」 |
| 发版 | 「做一个交互式 release」「发版要自动写 CHANGELOG」「npm 包怎么发」 |
| 上线 Web 产品 | 「新做的小产品上线」「部署 / CI / 定时任务一次性接好」「改了代码线上还是旧的」 |
| 桌面端 | 「网页版想做成桌面程序」「PWA 升级成 Tauri」「应用内自动更新」 |
| 钩子挂了 | 「`git commit` 报 `/usr/bin/env: 'sh': No such file or directory`」 |

**自测**：用户的问题是不是落在「提交 → 版本 → 打包 → 发布 → 部署」这条线上？是 → 就是本技能。

## 交付生命周期全景

| 阶段 | 通用动作 | 场景特有（见 references） |
|---|---|---|
| ① 提交规范 | commitlint 显式 type 列表 + husky `commit-msg` | — |
| ② 门禁 | husky `pre-commit` 跑 typecheck/测试（依赖没装时跳过，别卡住提交） | monorepo 多包 `typecheck` 聚合 → `01` |
| ③ 变更日志 | changelogen（或 monorepo 用 standard-version）按约定分组 | 多包 bump → `07` |
| ④ 版本与打标 | 交互式 `release.mjs`：选 patch/minor/major → bump → CHANGELOG → commit → tag → push | 版本号同步到 4 处（前端/Tauri/Capacitor/manifest）→ `06` |
| ⑤ 发布产物 | **CI 里发**，本地只 bump+tag+push | npm 包（token/provenance/files 白名单）→ `02` |
| ⑥ 部署 | 静态产物**重新 build + 重新 deploy**，并核对部署 ID / 资源 hash | Cloudflare Pages+Functions、Supabase → `03`/`04` |
| ⑦ 定时任务 | `schedule`（**cron 是 UTC**）+ `workflow_dispatch` 补跑 | 时区换算、防停用 → `05` |
| ⑧ 桌面端 | 多平台构建 + GitHub Release 附件 | Tauri 壳、签名、应用内自动更新 → `06` |

## 通用发布引擎（所有场景共用）

### commitlint：type 是封闭集，subject 不能大写起头

```bash
npm i -D @commitlint/cli@latest @commitlint/config-conventional@latest husky@latest changelogen@latest
```

用**显式 type 列表**（不只 `extends`），让允许的类型可见可维护 → 模板 `assets/commitlint.config.js`。

| 报错 | 原因 | 改法 |
|---|---|---|
| `subject must be lower-case` / `must not be sentence-case` | subject **以大写单词开头**，或**夹了大写英文词**（`API`/`UI`/`D1`）——**即使整句是中文**也会触发 | 改成小写或中文起头：`refactor(shared): 收敛 ListStrategy …`、`feat(web): api 客户端…` |
| `type must be one of [build, chore, ci, docs, feat, fix, perf, refactor, revert, style, test]` | type 是**封闭枚举**，**没有 `config`**（也没有 `deps`/`wip`/`hotfix`） | 站点/构建/基础设施配置用 `chore(<scope>)` 或 `build` |
| `header-max-length` | header > 100 字符 | 缩短 subject，细节挪 body |

> ⚠️ **绝不用 `--no-verify` 绕**。被拦说明门禁在工作，绕过去只是污染 history。

### CHANGELOG：三个必踩的配置坑

1. **文件名必须是 `changelog.config.js`，不是 `changelogen.config.js`**。changelogen 内部 `loadConfig({ name: 'changelog' })`（c12），名字错的文件**永不加载**，静默退回内置默认值 → 分组错、`repo` 被从 git remote 瞎推断。
  模板 `assets/changelog.config.js`，保持与 commitlint **同一套 type 与中文标题**。
2. **`types` 必须是 `Record`，不能是数组**。changelogen 0.6 用 `for (const type in config.types)` 读 `config.types[type].title`，老式数组写法被忽略：
   ```js
   feat: { title: '🚀 新功能 (Features)', semver: 'minor' }
   ```
3. **不带 flag 的 `changelogen` 只往 stdout 打印，不写文件**，版本头会退化成 `## v1.0.0...main`。要真 bump `package.json` 并追加 `## vX.Y.Z (YYYY-MM-DD)`，必须：
   ```bash
   npx changelogen --patch|--minor|--major --bump
   ```
4. **不要手写 `repo`**：只写 `{ provider, repo }` 缺 `domain` 会**抑制**推断并生成一堆 `https://undefined/...` 死链。留空让 changelogen 从 `package.json#repository` / git remote 推断。裸 slug（`'owner/name'`）也不行——字符串形态会被 `new URL()` 解析，只接受完整 URL。

### 交互式 release 脚本

模板 `assets/release.mjs`，流程：门禁（typecheck + test）→ 有未提交改动则提示提交信息 → 方向键选 `patch/minor/major`（实时预览下一个版本号 + 按类型分组的提交预览）→ Enter 执行 bump + 写 CHANGELOG → tag → commit → push。

- **`--dry-run` 必须透传到底层 bump 工具**并跳过 tag/push——这是**非 TTY 环境下唯一能自证脚本没坏**的方式。
- **非 TTY 下方向键选择器跑不了 → 脚本必须报错退出**（提示「specify patch|minor|major」），**绝不能挂住**。
- **把 deploy 从 release 里拆出去**：tag 一推就不可回滚，若 deploy 挂在脚本末尾，失败会留下「版本已发、站点还是旧的」这种看起来像发布失败的残局。打 tag 之后的一切都应该是独立、可重跑的命令，脚本只打印 `npm run deploy` 提示。

### husky 钩子 + `.git/cph` 兜底（Windows 高频）

`.husky/pre-commit`（**依赖没装时跳过，别卡住新克隆的仓库**）：

```sh
#!/bin/sh
if [ -d node_modules ]; then npm run typecheck; else echo "⚠ 依赖未安装，跳过 pre-commit 门禁"; fi
```

**症状**：`git commit` 报 `/usr/bin/env: 'sh': No such file or directory`。

**根因（关键）**：钩子进程的 `PATH` 取自**系统环境变量**，不是当前 shell——里面既没有 `Git\usr\bin` 也没有 `bash`。
所以 **在工具进程里 `$env:PATH += ...` 再 commit 完全无效**，必须靠钩子脚本自己找到可执行文件。

**解法**：在 `.git/cph/`（未跟踪，不动仓库配置）放两份兜底钩子：

```
git -c core.hooksPath=.git/cph commit -m "feat: xxx"
```

两条硬约束（否则依然静默失效）：

1. **shebang 必须 `#!/bin/sh`**，不能 `#!/usr/bin/env sh`（后者又要去 PATH 找 `sh`，踩同一个坑）。
2. **只用纯 shell 内建**：取目录用 `${VAR%/*}`，**别用 `dirname`**（外部命令）；调工具用 **`node <相对路径的本地 bin>`**。

**反例（踩过）**：`cmd.exe //c "npm.cmd ..."` 包装 → 「起个交互 cmd 就退出、exit 0」，看着跑过其实**门禁根本没跑**；且 node 收到 `/c/...` 会被 MSYS 错转成 `D:\c\...`。

> 兜底路径必须与原 husky **门禁内容等价**（同一份 typecheck / commitlint）。换 `hooksPath` 只是换执行方式，**不是绕过门禁的手段**。

### 发布放到 CI，本地只 bump + tag + push

- 本地 `npm run release` 负责 bump + 写 CHANGELOG + 提交 + 打 tag + push；**`on.push.tags: v*` 触发 workflow** 完成 校验 → 测试 → `npm publish` → 建 GitHub Release。
- npm 令牌只存仓库 Secret **`NPM_TOKEN`**（必须 **Automation** 类型；Publish 类型在 CI 会因 2FA 失败）。
- workflow 固定写法：Node **24** + `registry-url: https://registry.npmjs.org` + **`softprops/action-gh-release@v2`** + `npm publish --access public`；要 `--provenance` 须 `permissions: id-token: write` 且仓库公开。
- Release 说明：**优先取 CHANGELOG 本版本段落**，回退 `git log <prev>..<tag>`。**不要用 `gh release create --generate-notes`**——它只列有 PR 的变更，直推 main 的仓库会只剩一行 compare 链接。
- ⚠️ **`files` 是硬白名单且绕过 `.gitignore`**：目录级条目会把 `.env` / 本地库 / 日志一起打进 tarball（真实泄露过 CF 令牌）。发布前必跑 `npm pack --dry-run`。
  **把 pack 守卫写成带自测的脚本**：把「禁止/必需」规则做成数据，每次双向断言（`mustFlag` 的必须被抓、`mustPass` 的必须通过，把 `*.example` 放进 pass 列表）——正则白名单一旦有人删掉 `.env` 规则就静默腐烂，自测是唯一防线。
- `npm pack --json` 的输出是**以包名为 key 的对象**（不是数组），别按数组解析。

### 环境变量契约别被自己的脚本搞崩

项目若有「交叉校验每个 `process.env.X` 与 `.env.example`」的测试，发布脚本一读 `NO_COLOR` / `FORCE_COLOR` 就会**把绿仓库点红**。
这些是**终端约定、不是应用配置** → 加进测试的 `EXTERNAL_KEYS` 放行清单（与 `NODE_ENV`/`CI` 并列），**不要**写进 `.env.example`。
彩色输出用 `process.stdout.isTTY && !process.env.NO_COLOR` 把关。

### Windows 子进程铁律（本地脚本必守）

| 坑 | 正确做法 |
|---|---|
| `spawnSync('pnpm'|'npm', …)` 失败，报 `EBUSY`/`EINVAL`（**不是**有用的 `ENOENT`） | pnpm 常是**无扩展名的 shell 脚本**，Node 无法 exec。改为按路径调用 + `spawnSync(process.execPath, ['node_modules/<pkg>/bin/<cli>.js', …])`。常用入口：`typescript/bin/tsc`、`vitest/vitest.mjs`、`standard-version/bin/cli.js`、`@commitlint/cli/lib/cli.js`。这样与 PATH 无关、任意 cwd 都能跑。 |
| **管道化 stdin 也会 `EBUSY`**（受限/沙箱环境） | 只需 stdout 时用 `stdio: ['ignore','pipe','pipe']`；需要交互用 `'inherit'`。附带好处：不管道 stdin 后 git 永远不会挂住等输入。 |
| argv 含**用户提供的文本**（提交信息） | **不要 `shell: true`**（`& \| " <` 会被解释）。传 argv 数组，`shell: false`。 |
| 子进程 cwd 会被切换 | 传给子进程的 bin 路径**必须绝对**，否则被二次拼接（`packages\web\packages\web\...`）。 |

## 场景 A：npm 库/CLI

见 [`references/02-npm-library.md`](references/02-npm-library.md)。要点：CI 发布 + `NPM_TOKEN`(Automation) + provenance + `files` 白名单自测 + `npm pack --dry-run` 门禁 + 版本头与 CHANGELOG 对齐。

**若工具作为 npm CLI 分发，还要加「首次运行脚手架」**：入口脚本的 workspace 是 `process.cwd()`（不是包目录，否则产物落进 `node_modules`、重装或 npx 缓存清理后消失），空目录里没东西可跑 → 入口必须**幂等地补齐缺失的文件**。三条不变量，各配一个回归测试：

- **只创建缺失的** —— 绝不覆盖已有文件（测试里对预置文件做字节比对）；
- **绝不生成凭据/配置文件**，连占位符模板都不行——占位符会把「文件不存在→功能跳过」变成「文件存在→程序真的去发/连」，是**静默的行为变更**；只打印 `cp` 提示；
- **幂等且非致命** —— 脚手架出错只能降级成一行日志，绝不中断主流程。

给两个入口：真实工作前静默自动补齐 + 显式 `--init` 只初始化（必打印东西、必退出）。模板发 `*.example.json`，不发作者本人的真实数据文件。

## 场景 B：Web 产品上线（Cloudflare + Supabase）

详见 `references/03-cloudflare-pages-d1.md`、`04-supabase.md`、`05-github-actions.md`；模板 `assets/ci.yml`、`assets/scheduled.yml`。

默认技术选型（可替换）：

| 层 | 默认 | 备注 |
|---|---|---|
| 前端 | Vite + Vue 3（或任意 SPA） | 产物是静态文件，交给 Pages |
| API | Cloudflare Workers + Hono | 与前端**同源**部署，见下 |
| 数据 | Cloudflare D1（SQLite） | 或 Supabase Postgres，二选一或并用 |
| 鉴权 / 存储 | Supabase Auth / Storage | 自建用户体系成本高，优先托管 |
| 产物托管 | Cloudflare Pages | `*.pages.dev` 国内可达性优于 `*.workers.dev` |
| CI / 定时 | GitHub Actions | `schedule` + `workflow_dispatch` |

**最容易错的三件事**：

1. **前端直连 `*.workers.dev` → 国内不可达且要配 CORS**。正解：前端 Pages 项目里放 `functions/api/[[route]].ts`，把**同一个 Hono app** 挂到同源 `/api/*`——免跨域、免配置、绕开 workers.dev。业务逻辑只写一份（`worker/src/index.ts`），Pages 侧只做签名适配，**不要复制路由**。
2. **改了代码线上还是旧的**：静态产物必须**重新 build + 重新 deploy**（Pages 的 `dist` 不是仓库即产物）；部署后核对部署 ID / 资源 hash，别只看「部署成功」。
3. **D1 的 `IN (?,?,…)` 参数一多就抛错**：D1 单条语句绑定参数上限是 **100**（不是 SQLite 的 999），动态 `IN` 必须分块，块大小取 **90** 留余量。

其它：Worker 里**不要 `import 'dotenv/config'`**（用 `wrangler.toml` vars/binding + `wrangler secret put`，本地 `wrangler dev` 读 `.dev.vars`）；一切密钥走 GitHub Secrets / `wrangler secret` / Supabase 控制台，仓库只留 `*.example`。

## 场景 C：桌面应用（静态 PWA → Tauri v2）

见 [`references/06-tauri-desktop.md`](references/06-tauri-desktop.md)。要点：`web/` 单一前端源 + `src-tauri/` 壳；**线上优先 + 离线回落**（`ureq` 探测线上，3s 超时，不可达静默用打包资源）；`package.json#version` 为**唯一版本来源**同步到前端/Tauri/Capacitor/manifest 四处；多平台 CI 构建（web.zip / msi / exe / apk）；**应用内自动更新**（`tauri signer generate` → 私钥进 `TAURI_SIGNING_PRIVATE_KEY`、公钥进 `tauri.conf.json` → `tauri-action` 上传 `latest.json` + 签名包）。

## 验证清单

- `echo "foo: x" | npx commitlint` → exit 1；`echo "feat: x" | npx commitlint` → exit 0；`printf 'chore(release): 0.1.1' | commitlint` → exit 0（保证 bump 工具的提交不被拦）。
- **干净工作树**下 `node scripts/release.mjs --dry-run <type>` → 跑完两道门禁、打印 bump 预览、**什么都没写**（`git status` 干净、版本不变）。
- **非 TTY** 下 `node scripts/release.mjs --dry-run`（不带 type）→ 报「specify patch|minor|major」**而不是挂住**。
- 临时分支跑 `npx changelogen --patch --bump` → `package.json` 版本变了，且 `CHANGELOG.md` 新增 `## vX.Y.Z (date)` 且**中文分组正确**；验完回滚。
- `npm pack --dry-run` → 白名单里没有 `.env` / 本地库 / 日志。
- 线上 `/health` 返回统一信封；部署后资源 hash 确实变了。

## Resources

| 文件 | 内容 |
|---|---|
| `references/01-gates.md` | 门禁分层（本地/CI/部署前）、husky 钩子写法、commitlint 报错对照表 |
| `references/02-npm-library.md` | npm 包/CLI 发布：CI + Secrets、provenance、`files` 白名单自测、首次运行脚手架 |
| `references/03-cloudflare-pages-d1.md` | Pages + Functions 同源 `/api`、D1 建库/绑定/迁移、Worker 密钥 |
| `references/04-supabase.md` | Supabase 建项目/表/RLS/Auth/Storage，与 Cloudflare 的分工边界 |
| `references/05-github-actions.md` | CI 工作流、定时任务（cron UTC 换算）、手动补跑、Secrets、权限 |
| `references/06-tauri-desktop.md` | PWA→Tauri v2：目录结构、资源迁移、版本同步、多平台构建、签名与应用内自动更新 |
| `references/07-monorepo-bump.md` | monorepo 多包版本 bump（standard-version + `.versionrc.json`） |
| `assets/commitlint.config.js` | 显式 type 列表的 commitlint 配置 |
| `assets/changelog.config.js` | changelogen 配置（正确文件名 + `Record` 形 `types`） |
| `assets/release.mjs` | 交互式 release 脚本模板 |
| `assets/ci.yml` | CI 模板（多包并行 typecheck + build） |
| `assets/scheduled.yml` | 定时任务模板（UTC cron + dispatch + 自动提交产物） |
| `assets/tauri-release.yml` | Tauri 多平台构建 + 签名更新包模板 |

## 坑（合并后总表）

| 坑 | 一句话 |
|---|---|
| `changelogen.config.js` 这个名字 | 永不加载，静默退回默认值 |
| `types` 写成数组 | changelogen 0.6 只认 `Record`，数组被忽略 |
| `changelogen` 不带 `--bump` | 只打印不写文件，版本头退化成 `## ...main` |
| 手写 `repo` 缺 `domain` | 生成 `https://undefined/...` 死链；留空让它自己推断 |
| 本地跑 `npm publish` | 本机只 bump+tag+push，发布交给 CI（tag 触发） |
| `files` 白名单 | **硬白名单且绕过 `.gitignore`**，会连 `.env` 一起发；必跑 `npm pack --dry-run` |
| deploy 挂在 release 脚本末尾 | tag 已推不可回滚 → 「版本发了、站点还是旧的」 |
| `--dry-run` 没透传 | 非 TTY 下无法自证脚本，只能靠运气发版 |
| 钩子进程 PATH 不含 `sh` | `#!/usr/bin/env sh` 同样挂；必须 `#!/bin/sh` + 纯内建 + 相对路径直调 node |
| `spawnSync('pnpm')` / 管道化 stdin | 都报 `EBUSY`，不是 `ENOENT`；用 `process.execPath` + `stdio:['ignore','pipe','pipe']` |
| `env-contract` 测试被 `NO_COLOR` 点红 | 终端约定进 `EXTERNAL_KEYS` 放行清单，不进 `.env.example` |
| 前端直连 `*.workers.dev` | 国内不可达 + CORS；改同源 Pages Functions `/api` |
| D1 `IN (...)` 参数超 100 | D1 上限是 100（非 SQLite 999），分块取 90 |
| Actions `schedule` 时区 | cron 是 **UTC**，北京 15:35 → `35 7 * * 1-5`；长期无提交会被自动停用 |
| 部署"成功"但产物是旧的 | 静态产物必须重 build 重 deploy，核对部署 ID / 资源 hash |
| Tauri LNK1104 | 杀软锁 exe 或进程未退出；`taskkill` 或删 `target/release/deps/*.exe` |
| Tauri 更新包没签名 | 私钥进 Secret、公钥进 `tauri.conf.json`，由 `tauri-action` 出 `latest.json` |
