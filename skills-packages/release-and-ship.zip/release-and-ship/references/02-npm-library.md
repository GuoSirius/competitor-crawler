# 02 · npm 包 / CLI 发布

## 1. 分工：本地 bump，CI 发布

| 环节 | 在哪做 | 关键点 |
|---|---|---|
| 版本号 + CHANGELOG + tag | **本地** `npm run release` | 见主干「交互式 release 脚本」 |
| 校验 → 测试 → `npm publish` → GitHub Release | **CI**，`on.push.tags: v*` | 令牌只存仓库 Secret **`NPM_TOKEN`** |
| 回滚 | 不可回滚 | tag 是**不归点**；deploy 一类动作要拆出去独立可重跑 |

- **`NPM_TOKEN` 必须是 Automation 类型**（在 npm 账号 Settings → Tokens 生成）。用 Publish 类型在 CI 会因 2FA 直接失败，且报错不直观。
- 本地**永远不要** `npm publish`（本机不做发布，只做 bump/tag/push）。

## 2. GitHub Actions release workflow 固定写法

```yaml
name: release
on:
  push:
    tags: ['v*']
permissions:
  contents: write        # 建 Release
  id-token: write        # 仅当要 --provenance
jobs:
  publish:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 24
          registry-url: https://registry.npmjs.org
      - run: npm ci
      - run: npm test          # 或 typecheck + test
      - run: node scripts/check-pack.mjs      # 见 §3，发布前的白名单门禁
      - run: npm publish --access public      # 需要时加 --provenance
        env:
          NODE_AUTH_TOKEN: ${{ secrets.NPM_TOKEN }}
      - uses: softprops/action-gh-release@v2
        with:
          body_path: release-notes.md          # 由 §4 生成
```

- Node **24**（与本地一致，避免 engine 差异）。
- `--provenance` 需 `permissions: id-token: write` **且仓库公开**。

## 3. `files` 是硬白名单，且绕过 `.gitignore`（会真泄露）

package.json 里目录级条目会把 `.env`、本地数据库、日志**一起打进 tarball**——线上真实发生过 CF 令牌泄露。

**把守卫写成带自测的脚本**，而不是靠人眼每次看 `npm pack` 输出：

```js
// scripts/check-pack.mjs（示意）
const rules = {
  forbidden: ['.env', /\.sqlite$/, /\.log$/, /secret/i],
  required:  ['dist/index.js', 'README.md'],
  // 允许清单：必须"幸存"，防止正则过宽误杀（*.example 是模板，必须放行）
  mustPass:  ['.env.example'],
};
```

要点：
- 把「禁止 / 必需」做成**数据**，每次**双向断言**：`forbidden` 的必须被抓到、`mustPass` 的必须通过。
  正则白名单一旦有人删掉 `.env` 那条规则就**静默腐烂**——自测是唯一防线。
- 同时断言 `required`，让「tarball 里少了个文件」在 CI 就失败，而不是等到用户安装后报错。
- `npm pack --json` 的输出是**以包名为 key 的对象**（不是数组），别按数组解析。
- 本地排查：`npm pack --dry-run`、`npm pack --dry-run --json`。

## 4. Release 说明

- **优先**从 `CHANGELOG.md` 提取当前版本段落（`## vX.Y.Z` 到下一个 `##` 之间）。
- 回退：`git log <prevTag>..<tag>` 按**同一套 type 列表**分组。
- ⚠️ **不要用 `gh release create --generate-notes`**：它只列有 PR 的变更，直推 main 的仓库会只剩一行 compare 链接。

## 5. 工具作为 npm CLI 分发：首次运行脚手架

`bin/` 入口脚本通常把 workspace 设为 `process.cwd()`（**不是**包目录——否则产物落进 `node_modules`，重装或 npx 缓存清理后消失）。
于是空目录里"没东西可跑" → 入口必须**幂等地补齐缺失的文件**。

三条不变量，**每条都值得一个回归测试**：

| 不变量 | 为什么 |
|---|---|
| **只创建缺失的**，绝不覆盖已有文件 | 用户改过的配置不能被冲掉。测试里对预置文件做**字节比对** |
| **绝不生成凭据/配置文件**，连占位符模板都不行 | 占位符会把「文件不存在 → 功能跳过」变成「文件存在 → 程序真的去发/连」，是**静默的行为变更**。只打印 `cp` 提示 |
| **幂等且非致命** | 脚手架出错只能降级成一行日志，**绝不中断主流程** |

给两个入口：
- 真实工作前的**静默自动补齐**（无输出也无所谓，别打断）；
- 显式 **`--init`**：只初始化、**必定打印东西**、必定退出。

模板发 `*.example.json`（如 `trading_config.example.json`），**不要发作者本人的真实数据文件**。

## 6. 新包上线前

```bash
npm view <name> --registry=https://registry.npmjs.org   # 先查名字占用
npm view <name>@<ver> dist.tarball                       # 确认要装的确切版本
```

`package.json` 的 `private: true` 记得移除。
