# 07 · monorepo 多包版本 bump（standard-version）

当仓库有**多个 `package.json`**（pnpm/npm workspace），需要一次 bump 全部包时，`standard-version` + `.versionrc.json` 往往比 changelogen 省事。

## 配置

```json
{
  "tagPrefix": "v",
  "packageFiles": ["package.json"],
  "bumpFiles": [
    "package.json",
    { "filename": "packages/shared/package.json", "type": "json" },
    { "filename": "packages/crawler/package.json", "type": "json" },
    { "filename": "packages/web/package.json", "type": "json" }
  ]
}
```

## 用法

```bash
standard-version --release-as <patch|minor|major>
# 预览（不写树）
standard-version --release-as minor --dry-run
```

它会：
1. 按 `--release-as` bump `packageFiles` + 每个 `bumpFiles`；
2. 依据 Conventional Commits 写 `CHANGELOG.md`；
3. 提交 `chore(release): X.Y.Z`；
4. 打**附注 tag**（annotated）。

## 注意

- 它的 release 提交信息 `chore(release): X.Y.Z` **能过 `@commitlint/config-conventional`**
  （实测：`printf 'chore(release): 0.1.1' | commitlint` → exit 0），所以 `commit-msg` 钩子**不会**拦住发布提交。
- 推送用 `git push --follow-tags`（tag 是附注类型）。
- 支持 `--dry-run` **透传**——这是非 TTY 环境下唯一能自证发布脚本没坏的方式（见主干「交互式 release 脚本」）。
- 与 changelogen 的分工：**单包项目用 changelogen**（分组标题中文可控、`types` 是 `Record`）；**多包必须一次 bump** 时用 `standard-version`。
  同一个仓库**只用一种**，别混用（两份真相源 = 迟早不一致）。
- 从 `scripts/release.mjs` 调用时，同样遵守 Windows 子进程铁律：用
  `spawnSync(process.execPath, ['node_modules/standard-version/bin/cli.js', ...])`，并 `stdio: ['ignore','pipe','pipe']`。
