# GitHub：CI + 定时任务 + Release

一句话：CI 管**每次提交**，定时任务管**按点跑**，Release 管**发布留痕**；三者都放在 `.github/workflows/`，用 Secrets 拿凭据。

## 1. 三种工作流的分工

| 工作流 | 触发 | 典型动作 | 模板 |
|---|---|---|---|
| CI | `push` / `pull_request` | install → typecheck → build（多包并行） | `assets/ci.yml` |
| 定时任务 | `schedule` + `workflow_dispatch` | 抓数据 → 生成产物 → 提交回仓库 → 通知 | `assets/scheduled.yml` |
| Release | tag `v*` 或 `workflow_dispatch` | changelogen `--bump` → tag → GitHub Release | 见第 5 节 |

## 2. CI（每次提交都要过）

| 要点 | 做法 |
|---|---|
| 多包项目别串成一条龙 | 每个包一个 job（或一个 job 内 `--prefix` 分步），失败定位更快 |
| Node 版本 | `actions/setup-node` + `node-version-file: .nvmrc`，或显式写死大版本 |
| 装依赖 | `npm ci`（有 lockfile 才可重复）；多包用 `npm ci --prefix ./worker` 等 |
| 缓存 | `actions/setup-node` 的 `cache: npm` + `cache-dependency-path` 指向**多个** lockfile |
| 门禁内容 | `typecheck`（`tsc --noEmit` / `vue-tsc --noEmit`）+ `build`。**本地 husky 会拦，但 CI 才是最后一道** |
| 权限 | 只读场景显式 `permissions: contents: read`，最小权限 |

## 3. 定时任务（时区是最大的坑）

**`cron` 一律按 UTC 解释**，北京时间要减 8 小时：

| 想要的北京时间 | `cron` 写法 | 备注 |
|---|---|---|
| 每个工作日 09:00 | `0 1 * * 1-5` | 开盘前 |
| 每个工作日 15:35 | `35 7 * * 1-5` | 收盘后 |
| 每天 21:00 | `0 13 * * *` | — |
| 每小时 | `0 * * * *` | — |

其他必须做对的点：

| 项 | 做法 / 原因 |
|---|---|
| 手动补跑 | 一定加 `workflow_dispatch:`，否则跑挂了只能等第二天 |
| 重复触发 | 加 `concurrency: { group: <name>, cancel-in-progress: false }`，防止上一轮没结束又起一轮 |
| 要能 push 产物 | `permissions: contents: write`；否则 push 403 |
| 自动提交不要递归触发 | 提交信息带 `[skip ci]`，或用 `paths-ignore` 排除产物路径，或提交前判断 `github.actor` |
| 提交身份 | `git config user.name/email` 必须显式设（runner 默认身份会被拒） |
| **长期不活动会被停用** | GitHub 会停用无提交仓库的 schedule。让任务**产出可提交的产物**（快照/报告）最稳；否则每 60 天左右手工触发一次 |
| 产物要留痕 | 上传 `actions/upload-artifact`，同时把关键产物提交回仓库（便于 diff 与回溯） |
| 通知 | Server酱 / PushPlus / 邮件都用 Secrets 存 token，脚本里读环境变量，**不写进仓库** |
| 时区敏感的脚本内部 | 脚本自己也要用固定时区（如 dayjs + `Asia/Shanghai`），别依赖 runner 的本地时区 |

## 4. Secrets 与权限

| 放哪 | 放什么 |
|---|---|
| GitHub → Secrets → Actions | 部署 token、通知 token、service_role key、数据库连接串 |
| GitHub → Environments | 需要人工批准的部署（保护生产） |
| `wrangler secret put` | Worker 运行时机密（如 `WRITE_TOKEN`） |
| 仓库里 | 只有 `*.example` 模板 + 文档说明变量名 |

> **仓库名 / 账户名会影响**：Actions 里读 `github.repository` 而不是硬编码 owner/repo；否则 fork 后全挂。

## 5. Release

| 方式 | 命令 / 配置 | 适用 |
|---|---|---|
| 本地发 | 项目内 `npm run release`（changelogen `--bump` + tag） → `git push --follow-tags` | 手工控制版本号（推荐，见 `01-gates.md`） |
| CI 发 | tag `v*` 触发 → `actions/checkout` + `gh release create` | 打了 tag 就自动生成 Release 页 |
| 自动版本 | `changelogen --bump --release` | 全自动，但要小心误发 |

要点：`CHANGELOG.md` 与版本号**必须由同一份 commit 历史推导**（patch/minor/major 来自 commit type），否则会出现"代码是最新的、CHANGELOG 还停在两版前"。

## 6. 排查清单（工作流不跑 / 跑错）

- [ ] 文件在 `.github/workflows/` 下、扩展名 `.yml`，且 `on:` 缩进合法（YAML 缩进错 = 静默不触发）
- [ ] `schedule` 只有**默认分支**上的配置才生效
- [ ] cron 用的是 UTC（把时间往回推 8 小时核对一次）
- [ ] `workflow_dispatch` 存在，能在 Actions 页面点 "Run workflow"
- [ ] `permissions` 是否给了 `contents: write`（要 push 产物时）
- [ ] 需要 push 的步骤前有 `git config user.name/email`
- [ ] Secrets 名字与脚本里读的环境变量名完全一致（大小写敏感）
- [ ] 任务是否因仓库长期无提交被 GitHub 停用
