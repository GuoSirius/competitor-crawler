# 06 · 桌面应用：静态 PWA → Tauri v2 桌面壳

适用：项目已是纯前端静态 PWA（HTML/CSS/JS ESM），要**额外**提供 Windows/macOS/Linux 桌面程序；
并让 Web / Capacitor App / Tauri 桌面端**共用同一份前端构建产物**，不维护多份资源。

> 通用发布部分（提交规范、CHANGELOG、交互式 release、CI 发布）见主干，本文件只写**桌面端特有**的内容。

## 1. 核心目录结构

```
repo-root/
├── web/                    # 唯一前端源（PWA 静态资源）
│   ├── index.html  css/  js/  icons/
│   ├── manifest.webmanifest
│   └── sw.js
├── src-tauri/              # Tauri v2 桌面壳
│   ├── src/main.rs
│   ├── Cargo.toml
│   └── tauri.conf.json
├── app/                    # Capacitor App（可选）
│   ├── capacitor.config.ts
│   └── sync.mjs
├── tools/
│   ├── sync-version.mjs           # 版本同步
│   ├── release.mjs                # 交互式发布（见主干模板）
│   └── extract-release-notes.mjs  # GitHub Release 说明提取
├── CHANGELOG.md
└── .github/workflows/release.yml
```

## 2. 迁移前端资源到 `web/`

1. 把根目录的 `index.html css js icons manifest.webmanifest sw.js` 移到 `web/`；
2. 本地开发服务器脚本的根目录改为 `web/`；
3. Capacitor 同步脚本：源 `web/` → 目标 `app/www/`；
4. `wrangler.toml` 的 `pages_build_output_dir = "web"`（部署命令也要跟着改，见 §7）；
5. 所有测试脚本与 README 里的路径引用同步更新；
6. `tauri.conf.json` 用 `"frontendDist": "../web"`。

## 3. Tauri「线上优先 + 离线回落」

`src-tauri/src/main.rs` 的 `setup` 中：

- Release 构建启动时先用 `ureq` 探测线上地址（如 `https://your-site.pages.dev`），**超时 3 秒**；
- 可达 → `window.navigate(url)` 加载线上版本（改完前端即时生效，不用重装）；
- 不可达 → **静默失败**，继续用打包进二进制的本地 `web/` 资源；
- Dev 模式用 `#[cfg(not(debug_assertions))]` 跳过探测，仍走 `devUrl`。

```toml
# Cargo.toml
ureq = { version = "2", default-features = false, features = ["tls"] }
```

⚠️ 闭包 move 问题：把 `online_url` **clone** 一份给 `spawn_blocking` 闭包，外部保留原串用于 `parse()`。

## 4. 版本号唯一来源与同步

以根 `package.json` 的 `version` 为**唯一来源**，`node tools/sync-version.mjs` 同步到：

| 目标 | 用途 |
|---|---|
| `web/js/version.js` | 前端运行时 import，设置页「关于」显示 |
| `src-tauri/tauri.conf.json` | Tauri 桌面壳版本 |
| `app/package.json` | Capacitor App 版本 |
| `web/manifest.webmanifest` | PWA manifest 的自定义 `version` 字段 |

`tools/release.mjs` 在 bump 版本后**自动调用** sync-version。

> 若不统一来源，升级会漏掉某端 → 出现「桌面端显示 1.0.1、Web 显示 1.0.2」这类问题。

## 5. 交互式发布流程（本项目版）

`package.json` 只保留 `"release": "node tools/release.mjs"`。流程：

1. `npm test` 自测；
2. 检查 `git status --porcelain`，有未提交改动 → 提示输入提交信息并提交；
3. 箭头菜单选 `patch / minor / major`，实时显示 `1.0.0 → 1.0.1`；
4. Enter 确认后再 `y/N` 二次确认；
5. `npm version <level> --no-git-tag-version`；
6. 跑 `sync-version`（§4）；
7. 从上一个 tag 到 HEAD 提取 `git log` 追加到 `CHANGELOG.md` 顶部；
8. `git add -A && git commit -m "chore(release): vX.Y.Z"`；
9. `git tag -a vX.Y.Z -m "vX.Y.Z"`；
10. `git push origin HEAD --follow-tags`。

**CHANGELOG 分组**（与 commitlint 的 type 对齐）：

| type | 标题 |
|---|---|
| `feat` | Features |
| `fix` | Bug Fixes |
| `ui` | UI |
| `perf` | Performance Improvements |
| `refactor` | Code Refactoring |
| `style` | Styles |
| `test` | Tests |
| `build` | Build System |
| `ci` | CI/CD |
| `chore` | Chores |
| `docs` | Documentation |
| 其它 | Other |

```markdown
## [1.0.2] - 2026-08-13

### Features

- **sync:** 接入云端同步 ([a1b2c3d])

### Bug Fixes

- **board:** 修复选中格高亮 ([d4e5f6g])
```

⚠️ `tools/extract-release-notes.mjs <tag>` 从 `CHANGELOG.md` 提取当前版本内容时，
**正则不要用 `m` 标志配合 `$`**——多行的 `$` 会让非贪婪捕获提前截断。

## 6. GitHub Actions 多平台构建

`assets/tauri-release.yml`（触发 `push.tags: v*.*.*`）：

| job | 做什么 | 产物 |
|---|---|---|
| `build-web` | 装依赖、跑测试、把 `web/` 打成 `web.zip` | artifact |
| `build-tauri` | Windows runner 装 Node + Rust，`npm run tauri:build` | `msi`、`nsis/*.exe` |
| `build-android` | Ubuntu runner 装 Node/Java/Android SDK，`cap add android` + `cap sync` + `gradlew assembleDebug` | debug APK |
| `release` | 汇总 artifacts，用 `extract-release-notes.mjs <tag>` 取说明，建 GitHub Release 并上传附件 | Release |

## 7. 应用内自动更新（Tauri updater）

### 7.1 装依赖

```bash
npm install @tauri-apps/plugin-updater
cd src-tauri && cargo add tauri-plugin-updater
```

### 7.2 生成签名密钥对

```bash
npx tauri signer generate -w /path/to/keep-secret/your-app.key -f --ci
```

- **私钥（`.key`）切勿提交仓库**：存安全位置并写进 GitHub Actions Secrets → `TAURI_SIGNING_PRIVATE_KEY`。
- 公钥（`.key.pub`）内容写入 `src-tauri/tauri.conf.json` 的 `plugins.updater.pubkey`。

### 7.3 配置 `tauri.conf.json`

```json
"plugins": {
  "updater": {
    "active": true,
    "dialog": false,
    "endpoints": [
      "https://github.com/<owner>/<repo>/releases/latest/download/latest.json"
    ],
    "pubkey": "<public-key-base64>",
    "windows": { "installMode": "basicUi" }
  }
}
```

### 7.4 初始化插件与权限

`src-tauri/src/main.rs`：

```rust
.plugin(tauri_plugin_updater::init())
```

`src-tauri/capabilities/default.json` 增加：

```json
"updater:default",
"updater:allow-check",
"updater:allow-download",
"updater:allow-install"
```

### 7.5 前端检测与安装

```js
import { check } from '@tauri-apps/plugin-updater';
const update = await check();
if (update) {
  // 先弹窗让用户确认
  await update.downloadAndInstall((event) => {
    if (event.event === 'Finished') toast('更新已下载，请重启应用');
  });
}
```

建议：
- 启动时按用户设置（`updateCheck: 'startup' | 'manual' | 'off'`）决定是否静默检测；
- 设置页给「更新检测」分段 + 「检查更新」按钮；
- **非 Tauri 环境**（浏览器/PWA）提示刷新即可；**Capacitor 环境**引导到 GitHub Release 页下载 APK。

### 7.6 CI 出签名更新包

`build-tauri` job 改用 `tauri-apps/tauri-action@v0` 并传签名私钥：

```yaml
- uses: tauri-apps/tauri-action@v0
  env:
    GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
    TAURI_SIGNING_PRIVATE_KEY: ${{ secrets.TAURI_SIGNING_PRIVATE_KEY }}
  with:
    projectPath: ./src-tauri
    args: --target x86_64-pc-windows-msvc
    releaseName: ${{ github.ref_name }}
    tagName: ${{ github.ref_name }}
```

`tauri-action` 会自动生成并上传 `latest.json` + 签名安装包；前端的 `check()` 拉这个文件完成更新检测。

## 8. 常见问题

| 现象 | 原因 / 解法 |
|---|---|
| **Tauri 链接失败 LNK1104** | 多为杀软 / Windows Defender 锁住新生成的 exe，或旧 exe 进程未退出。先 `taskkill /F /IM <app>.exe`，或删 `src-tauri/target/release/deps/<app>.exe` 再试 |
| **Cloudflare Pages 部署路径** | 目录迁移到 `web/` 后，`wrangler pages deploy .` 要改成 `wrangler pages deploy web` |
| **Capacitor 找不到资源** | `capacitor.config.ts` 的 `webDir` 保持 `www`，每次构建前跑 `app/sync.mjs` 从 `web/` 同步 |
| **GitHub Release body 提取失败** | 确保发布前 `CHANGELOG.md` 已含对应版本的 `## [x.y.z] - YYYY-MM-DD` 节 |
| 桌面端版本和 Web 不一致 | 忘了跑 `sync-version`（§4）；release 脚本里应自动调用 |
| 签名私钥泄漏 | 私钥只进 Secrets；仓库里只留公钥 |
