# Cloudflare：Workers + D1 + Pages（同源 `/api`）

一句话：**API 只写一份 Hono 应用**，同时以 Worker 和 Pages Functions 两种形态发布，前端与 API 同源，免 CORS、不碰 `*.workers.dev`。

## 1. 文件布局

| 路径 | 作用 |
|---|---|
| `worker/src/index.ts` | Hono app 本体（**唯一**业务实现） |
| `worker/src/lib/` | `db.ts`（SQL）、`response.ts`（统一信封）、`auth.ts`（写鉴权）等 |
| `worker/src/pages.ts` | Pages Functions 适配层：`export const onRequest = handle(app)` |
| `worker/wrangler.toml` | Worker 配置 + D1 绑定 |
| `worker/.dev.vars`（gitignore） | 本地机密，`wrangler dev` 自动读 |
| `web/functions/api/[[route]].ts` | 把 `/api/*` 全部交给同一个 Hono app |
| `web/public/_routes.json` | 声明哪些路径走后端（避免静态资源被 Functions 拦） |
| `db/schema.sql` | D1 建表脚本（带列注释） |
| `db/d1client.js` | 用 REST API 直连 D1（本地脚本灌数据用） |

## 2. 关键代码

### 2.1 Pages Functions 适配层 `worker/src/pages.ts`

```ts
// 不要在这里 import hono —— web/ 没装 hono，靠 worker/node_modules 解析；
// 跨目录引用统一收敛到本文件，避免 esbuild 从 web/ 侧解析不到依赖。
import { handle } from 'hono/cloudflare-pages';
import app from './index.js';

export const onRequest = handle(app);
```

### 2.2 前端侧文件路由 `web/functions/api/[[route]].ts`

```ts
// Hono app 内部路由本身已带 /api 前缀，这里不要再 basePath('/api')，否则会变成 /api/api/*。
export { onRequest } from '../../../worker/src/pages.js';
```

### 2.3 `worker/wrangler.toml`

```toml
name = "my-api"
main = "src/index.ts"
compatibility_date = "2025-01-01"
compatibility_flags = ["nodejs_compat"]

[[d1_databases]]
binding = "DB"                       # 代码里 c.env.DB
database_name = "my-db"
database_id = "<wrangler d1 create 返回的 id>"
```

> `web/wrangler.toml` 里只需 `pages_build_output_dir = "dist"`，**不需要**再配 D1 —— Pages 的 Functions 复用 `web/functions/` 下的转发，最终跑到 Worker 侧那份代码。

## 3. 命令清单

| 目的 | 命令 |
|---|---|
| 建库 | `wrangler d1 create my-db` |
| 看库信息 / 取 id | `wrangler d1 info my-db` |
| 建表（远程） | `wrangler d1 execute my-db --remote --file db/schema.sql` |
| 建表（本地） | `wrangler d1 execute my-db --local --file db/schema.sql` |
| 查一条 | `wrangler d1 execute my-db --remote --command "SELECT COUNT(*) FROM t"` |
| 写机密 | `wrangler secret put WRITE_TOKEN`（**交互输入，别写进命令行历史**） |
| 本地起 API | `wrangler dev`（自动读 `.dev.vars`）；`--remote` 走真实 D1 |
| 部署（唯一发布动作） | `npm run deploy --prefix ./web`——静态资源 + Functions 一起上线。**同源方案不需要独立 Worker，别再 `wrangler deploy`** |

## 4. D1 专项坑（真实踩过）

| 坑 | 现象 | 做法 |
|---|---|---|
| 绑定参数上限 **100** | `IN (?,?,…)` 一多直接抛错 → 被 `onError` 兜成 500 | 动态 `IN` **分块**，块大小 **90**（留余量），取回后在内存 `Map` 分组 |
| `/execute` 路由 404 | 用 REST 直连时 `POST /accounts/:id/d1/database/:id/execute` 返回 `Route not found`；`/query` 也不收 `{statements:[…]}` | 改用 `/query` **逐条**提交 `{sql, params}`，并发限制在 10 左右 |
| `last_insert_rowid()` 不可靠 | 跨语句可能不在同一连接 | 用 `INSERT … RETURNING *` 拿回插入行 |
| 大小写 / 类型漂移 | SQLite 弱类型 | 落库前在 `normalize.js` 统一：数字转 number、时间转字符串、`null` 明确写入 |
| 回填重复写 | 重跑脚本会覆盖新数据 | 每行带 `run_at`，用「仅当更新值更新才覆盖」的 recency guard |
| 列不够用 | 需求新增字段 | 惰性迁移：`ensureColumns()` 用 `PRAGMA table_info` + `ALTER TABLE ADD COLUMN` |

## 4.5 Pages 专项坑（真实踩过）

| 坑 | 现象 | 做法 |
|---|---|---|
| `wrangler pages deploy` 不支持 `--config` | 传了直接报错 | 必须在 `web/` 目录下执行（读该目录的 `wrangler.toml`），别在根目录试图指路径 |
| Pages 项目改 secrets 不生效 | `wrangler pages secret put WRITE_TOKEN` 成功了，线上写接口还是 10005 | **secrets 改动需要一次新部署才生效**：先 put 再重新 deploy |
| 部署了两套 API（Worker + Functions） | 改了 Worker 代码线上没变化（或行为不一致） | 同源方案下 `/api` 只由 Pages Functions 提供；独立 Worker 顶多留作本地 dev 后端，**不进发布流程** |

## 5. 校验清单（每一步都能自证）

- [ ] `curl https://<pages 域名>/health` → `{ "code": 200, "message": "…", "data": {...} }`
- [ ] 前端页面在**不配任何 API 地址**的情况下能取到数据（证明同源 `/api` 生效）
- [ ] `wrangler d1 execute … --remote --command "SELECT COUNT(*) …"` 行数与预期一致
- [ ] 未配置 `WRITE_TOKEN` 时写接口返回业务码 `10005`（而不是静默成功）
- [ ] 旧数据回填后，前端历史列表无 `—` 空洞
