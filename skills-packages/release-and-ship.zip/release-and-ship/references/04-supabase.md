# Supabase：当托管后端用（Postgres / Auth / Storage）

一句话：Supabase = 托管 Postgres + 内置 Auth + 对象存储 + 自动 REST/Realtime。
**适合「需要用户体系和关系型数据」的产品**；若只是几个只读列表，Cloudflare D1 更轻。

## 1. 什么时候用哪个

| 需求 | 选 Supabase | 选 Cloudflare D1 |
|---|---|---|
| 用户注册 / 登录 / 第三方登录 | ✅ 内置 Auth，别自建 | ❌ |
| 多用户数据隔离（行级权限） | ✅ RLS 天然支持 | ❌ 要自己在 API 层过滤 |
| 图片 / 文件上传 | ✅ Storage + CDN | 用 R2 |
| 复杂 JOIN / 窗口函数 / 扩展 | ✅ 真 Postgres | ⚠️ SQLite 受限 |
| 只读看板 / 单用户工具 | 过重 | ✅ 零运维、Worker 原生绑定 |
| 冷启动 / 成本 | 免费额度有限、可能休眠 | D1 免费额度大、无冷启动 |
| 组合用法 | 数据在 Supabase，API 仍走 Worker/Pages（Worker 用 service_role 走 REST）；或前端直连 Supabase（anon key + RLS） | — |

## 2. 建项目与安全边界（最要紧的一节）

| Key | 能不能进前端 | 说明 |
|---|---|---|
| `anon`（public）key | ✅ 可以 | 权限**完全**由 RLS 决定。**RLS 没开 = 等于把库公开** |
| `service_role` key | ❌ **绝对不行** | 绕过一切 RLS，等同数据库超管。只放服务端（Worker / CI Secret） |
| `SUPABASE_JWT_SECRET` / DB 密码 | ❌ | 只放服务端 / Secrets |

> **最容易翻车的一条**：新建表后忘记 `ENABLE ROW LEVEL SECURITY`，Supabase 默认策略会让 `anon` 直接读写全表。**建表脚本里必须紧跟 RLS + policy，不能分两步做**。

## 3. 建表 + RLS 模板

```sql
-- 1) 业务表
create table if not exists public.notes (
  id          bigint generated always as identity primary key,
  user_id     uuid not null default auth.uid(),      -- 归属当前登录用户
  content     text not null check (char_length(content) between 1 and 500),
  created_at  timestamptz not null default now()
);
create index if not exists idx_notes_user on public.notes(user_id);

-- 2) 开 RLS（漏了这行 = 公开库）
alter table public.notes enable row level security;

-- 3) 策略：本人只能读写自己的行（分开写，语义更清楚）
create policy "notes_select_own" on public.notes
  for select using (auth.uid() = user_id);
create policy "notes_insert_own" on public.notes
  for insert with check (auth.uid() = user_id);
create policy "notes_update_own" on public.notes
  for update using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "notes_delete_own" on public.notes
  for delete using (auth.uid() = user_id);

-- 4) 只读公共表（无用户概念时）：只给 select，别 grant all
create policy "public_read" on public.posts
  for select using (published = true);
```

## 4. 前端接入（最简单的路径）

```ts
// 环境变量名：Vite 只暴露 VITE_ 前缀；Next 用 NEXT_PUBLIC_。写错前缀 → undefined。
import { createClient } from '@supabase/supabase-js';
const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL as string,
  import.meta.env.VITE_SUPABASE_ANON_KEY as string,   // 只放 anon key
);
```

`.env.local`（gitignore）与 CI 里的 Secrets 用**同名**变量，避免"本地能跑、线上不行"。

## 5. 服务端 / Worker 侧接入

- 走 REST：`https://<ref>.supabase.co/rest/v1/<table>`，头带 `apikey: <service_role>` + `Authorization: Bearer <service_role>`。
- 走 Postgres 直连（本地脚本）：`DATABASE_URL=postgres://…`，记得 `sslmode=require`。
- **service_role 只在服务端**；前端要写数据就让它带用户 JWT 走 anon key + RLS。

## 6. Storage

| 桶类型 | 用途 | 注意 |
|---|---|---|
| public | 可公开访问的图片/素材 | 直接给 CDN 链接 |
| private | 用户私有文件 | 用 `createSignedUrl()` 生成**有时效**的链接，别设过长有效期 |

## 7. 校验清单

- [ ] 建表脚本里每张表后面都能看到 `enable row level security`
- [ ] 用 `anon` key 匿名请求别人的数据 → 返回空数组（**不是**返回数据、也**不是**报 500）
- [ ] 用 `anon` key 直接 insert 不属于自己的 `user_id` → 被 `with check` 拒绝
- [ ] 前端构建产物里 grep 不到 `service_role`
- [ ] 本地 `.env.local` 与 CI Secrets 变量名一致
