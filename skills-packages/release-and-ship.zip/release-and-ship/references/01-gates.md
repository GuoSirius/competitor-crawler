# 01 · 本地门禁：typecheck / commitlint / husky

一句话：**能在本地拦下的错误，不要留给 CI**；发布必须由 commit 历史机械推导，不靠人记版本号。

## 1. 门禁分层

| 层 | 拦什么 | 触发点 |
|---|---|---|
| husky `pre-commit` | 类型错误（多包各自 `typecheck`） | `git commit` |
| husky `commit-msg` | 提交信息不符合 Conventional Commits | `git commit` |
| CI（见 `05-github-actions.md`） | 同上 + 构建失败 | push / PR |
| 部署前 | 产物是否**真的换了**（部署 ID / 资源 hash） | 手工或 CI 步骤 |

多包项目的 `typecheck` 统一写法（根 `package.json`）：

```json
{
  "scripts": {
    "setup": "npm install && npm install --prefix ./worker && npm install --prefix ./web",
    "typecheck": "npm run typecheck --prefix ./worker && npm run typecheck --prefix ./web",
    "release": "node scripts/release.mjs",
    "prepare": "husky"
  }
}
```

> 为什么不把各包 `typecheck` 全塞进 CI 就完事：CI 一次往返要几分钟，本地钩子只要几秒；
> 而且**提交信息**这类东西 CI 拦下来时已经进了 history，改起来要 rebase。

## 2. husky 钩子

`.husky/pre-commit` —— **依赖没装时跳过，别卡住新克隆的仓库**（这条很实用，新克隆/CI 缓存未命中时不该因为门禁跑不了而无法提交）：

```sh
#!/bin/sh
if [ -d node_modules ] && [ -d worker/node_modules ] && [ -d web/node_modules ]; then
  npm run typecheck
else
  echo "⚠ 依赖未安装，跳过 pre-commit typecheck 门禁"
fi
```

`.husky/commit-msg`：

```sh
#!/bin/sh
npx --no -- commitlint --edit "$1"
```

`package.json` 加 `"prepare": "husky"`，让 `npm install` 后自动装钩子。

## 3. commitlint 常见的「看着没问题却被拦」

| 报错 | 原因 | 改法 |
|---|---|---|
| `subject must be lower-case` / `must not be sentence-case` | subject **以大写单词开头**，或**夹了大写英文词**（`API` / `UI` / `D1` 等）。`config-conventional` 要求 subject 小写——**中文不影响，但夹带的英文缩写会触发** | 改小写或中文起头：`feat(web): api 客户端补写接口…`、`refactor(shared): 收敛 ListStrategy …` |
| `type must be one of [build, chore, ci, docs, feat, fix, perf, refactor, revert, style, test]` | type 是**封闭枚举**，**没有 `config`**（也没有 `deps`/`wip`/`hotfix`） | 站点/构建/基础设施配置用 `chore(<scope>)` 或 `build`；中文只能放冒号后 |
| `header-max-length` | header 超过 100 字符 | 缩短 subject，细节挪进 body |
| `subject-full-stop` | subject 以句号结尾 | 去掉句号 |

> ⚠️ 拦截点在设计上就是**提交时**：宁可本地被拦一次，也**绝不要用 `--no-verify` 绕过去**污染 history。
> 绕过一次，后面所有「为什么这个提交没进 CHANGELOG」都得重新查一遍。

## 4. 钩子跑不起来时的替代方案（Windows 高频）

见主干 SKILL.md「husky 钩子 + `.git/cph` 兜底」。核心三点再强调一遍：

1. 症状是 `git commit` 报 `/usr/bin/env: 'sh': No such file or directory`；
2. 根因是**钩子进程的 PATH 取自系统环境变量**，不含 `Git\usr\bin` / `bash` → 改父进程 `$env:PATH` **完全无效**；
3. 兜底钩子必须 `#!/bin/sh`（**不能** `#!/usr/bin/env sh`）+ 只用纯 shell 内建（用 `${VAR%/*}` 而非 `dirname`）+ `node <相对路径本地 bin>`；
   提交时 `git -c core.hooksPath=.git/cph commit ...`。**门禁内容必须与 husky 等价**，`hooksPath` 不是绕过门禁的手段。

## 5. 校验清单

```bash
echo "foo: x"   | npx commitlint   # → exit 1（未知 type 被拒）
echo "feat: x"  | npx commitlint   # → exit 0
printf 'chore(release): 0.1.1' | npx commitlint   # → exit 0（bump 工具的提交不被拦）
echo 'refactor(x): ListStrategy 收敛' | npx commitlint   # → exit 1（大写起头被拒，用来验证钩子确实生效）
```

最后一条是**故意造一个不合规提交来确认门禁在工作**——比"看起来配好了"可靠。
