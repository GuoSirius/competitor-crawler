---
name: pdf-keyword-extraction
description: 爬取网页上的 PDF 列表并为每个 PDF 提取英文关键词，输出 title/pdfUrl/keywords（可含 section）的 Excel 与合并后的 JSON。适用于"为页面内搜索 / 中台检索框准备每本资料的关键词"类任务。触发词：页面内搜索关键词、PDF 关键词提取、爬取 PDF 列表做检索、资源页关键词表。
agent_created: true
version: "1.0.0"
display_name: "PDF 关键词提取与表格化"
display_name_en: "PDF Keyword Extraction"
description_zh: "爬取网页上的 PDF 列表并为每个 PDF 提取英文关键词，输出 title/pdfUrl/keywords 的 Excel 与合并后的 JSON，用于页面内搜索或中台检索框。"
description_en: "Crawl PDF lists from web pages, extract English keywords per resource, and output an Excel plus merged JSON with title/pdfUrl/keywords for site search."
---

# PDF 关键词提取与表格化

## 适用场景
- 给定某个资源列表页 URL，页面用 `<li class="zl-content">` 罗列资源（每个条目含 `<a href="...pdf/.png/.jpg">` 与标题 `<p class="mb-0 mt-2">`）。
- **资源既可能是 PDF，也可能是图片格式的海报/传单（.png/.jpg/.jpeg）**——站点的 "Posters and Flyers" 页常混排。必须按"卡片条目"计数，而不是按 `.pdf` 计数。
- 需要为**每个资源条目**产出英文关键词（核心主题 + 技术词 + 产品编号），用于页面内搜索或中台检索框。
- 交付：Excel（列 `section`/`title`/`pdfUrl`/`keywords`，超长拆 `keywords_2`）+ 合并后的 JSON（纯数组，字段 `section,title,pdfUrl,keywords`）。

## 完整流程
1. **抓页**：`curl -sL <url> -o page.html`（浏览器 UA，否则 403；HTTP 200 后检查 `<li class="zl-content">` 数量）。
2. **解析**：BeautifulSoup，`soup.select("li.zl-content")`，对每个条目取 `a[href]`（**接受 .pdf/.png/.jpg/.jpeg 全部类型**）与 `<p class="mb-0 mt-2">` 文本作 title → 写 `items.json`（字段 `index,section,title,pdfUrl,ext,fileType,localFile`）。**绝不写死只认 `.pdf`**，否则会少算图片型条目。
3. **下载**：按 `ext` 真实后缀保存（如 `.png`/`.jpg`），校验按文件魔数（`%PDF` / `\x89PNG` / `\xff\xd8\xff`；jpg 用 `[:3]` 不是 `[:4]`）；把实际 `localFile` 写回 `items.json`。
4. **抽取文本 / OCR**：PDF 用 PyMuPDF 提取文本层；文本层为空 / 图片型 PDF / 纯图片资源 → PaddleOCR。
5. **关键词组装**（见下）：`clean_title` + 手写 curated `THEME` + 正则自动抽产品编号 → 去重（大小写不敏感、保序）。
6. **写 Excel**：openpyxl；单关键词串 > 30000 字符拆列。
7. **转 JSON**：合并 `keywords_2` → `keywords`，字段 `section,title,pdfUrl,keywords`。

## ⚠️ 数量核对铁律（本任务两次踩坑）
- **用户按"页面卡片数"验收，不是按 PDF 数**。解析后立刻对比：网站 `li.zl-content` 卡片总数 == items.json 行数 == 已下载文件数 == 成品 Excel 数据行数。**四者对不上就是 bug**。
- 最易漏的就是**图片格式条目**（`.png`/`.jpg` 海报混在 `.pdf` 里）。解析器必须收录全部扩展名，否则会少算（例：ELISA 页 20 张卡片 = 14 PDF + 6 图片，只认 `.pdf` 会错报成 14）。
- 重抓线上页做差集时，若字节数与旧快照一致，说明站点未变、快照完整；若不一致才需要补。

## 关键词策略（核心，保证"多而全且无无意义词"）
- **不要**直接用 LLM 生成的 TOP TERMS 作关键词——会混入碎片（如 "High-Quality Flow Cytometry Antibody Reliable"、"IgDow YY CD268"）。
- 改为三件套：
  1. `clean_title(title)` 去后缀括号作核心主题词；
  2. 每 PDF **手写**一份 curated 主题/技术词列表（基于 digest + OCR 内容，干净无碎片）；
  3. **正则自动抽产品编号**（见下），保证编号类关键词齐全且不脏。
- 去重：用 `seen=set(); key=kk.lower()` 保序去重。

## 产品编号正则（elabscience 场景，按站点扩展）
```python
CAT_RE = re.compile(
    r'\b(E-AB-[A-Z0-9]+|E-CK-[A-Z0-9]+|E-LK-[A-Z0-9]+|E-BC-[A-Z0-9]+|'
    r'E-FC-[A-Z0-9]+|E-HS[A-Z]+-[A-Z0-9]+|E-BR-[A-Z0-9]+|MIM[0-9][A-Z]?|'
    r'MIH[0-9][A-Z]?|XJ[HM][0-9]+|EBR[0-9]+|PKS[HM][0-9]+|EFL[0-9]+|'
    r'EPO[0-9]+|HI[0-9]+|AN[0-9]+[A-Z]?|BL[0-9]+|CD[0-9]+[A-Z]?|ISO9001)\b'
)
```

## 关键技术坑（必看，否则会白干）
- **解析只认 `.pdf` 会漏掉图片条目（最隐蔽的"数量对不上"）**：站点 "Posters and Flyers" 页常把海报/传单存成 `.png`/`.jpg`（URL 也在 `documents/pdf/` 目录下，只是后缀是图片）。`soup.select("li.zl-content")` 后务必接受 `.pdf/.png/.jpg/.jpeg` 全部类型，并用 `urlparse(href).path` 的扩展名判断。漏掉时表现为"用户说页面有 N 条、你只有 M 条（M<N）"。
- **PaddleOCR 3.x API 已改（3.7.0 验证）**：旧 `.ocr(img, cls=True)` 在 3.x 报 `PaddleOCR.predict() got an unexpected keyword argument 'cls'`。改用 `.predict(img)`；返回值是 `list[OCRResult]`（dict-like），文本行取 `r["rec_texts"]`（或 `r.rec_texts`）。`extract_lines` 需兼容此结构。构造函数 kwargs 不变（`lang/ocr_version/enable_mkldnn` 等）。
- **沙箱 safe-delete 拦截 `os.remove` 导致 OCR 中断**：删除临时渲染图 `os.remove(imgp)` 可能被 WorkBuddy 安全删除钩子拦截抛 `OSError('SHFileOperationW 失败: 0x2')`，若该语句在循环内且未容错，会让整本 PDF 的 OCR 失败、不落盘。务必 `try: os.remove(imgp); except Exception: pass`，并在 `ocr_resource` 开头对"已存在且非空"的 ocr txt 直接 SKIP（支持断点续跑/重跑只补缺失）。
- **OCR 跳过逻辑必须用"文本量阈值"，不能"texts/ 非空即跳过"（隐蔽的数量/质量坑）**：`extract_text.py` 会对**所有** PDF 写 `texts/<base>.txt`（真实文本层写全文、image-only PDF 常写出 1~199 字符碎片或 0 字节）。若 `ocr_resource` 仅以"`texts/` 存在且非空"就跳过 OCR，那 47 个本需 OCR 的 PDF 会被误跳过，关键词只用到碎片文本（更惨的是交付物"看似齐全"）。**正确做法**：以与 `extract_text` 一致的 `TEXT_LAYER_MIN = 200` 为界——只有 `os.path.getsize(texts) >= 200` 才视为真实文本层跳过 OCR；空文件或碎片（<200）一律继续走 OCR 拿完整文本。重跑 OCR 前若想强制全量，先 `rm -rf work/<slug>/ocr` 再跑（`ocr_resource` 对"已存在非空 ocr txt"默认 SKIP，不清会漏重跑）。
- **URL 二次编码 → 404**：已含 `%20`/`%2B`/`%26` 的 URL 不能再次 `quote()`（会变成 `%2520` 直接 404）。先 `unquote` 再 `quote`：
  ```python
  from urllib.parse import urlsplit, urlunsplit, quote, unquote
  def enc(url):
      p = urlsplit(url)
      return urlunsplit((p.scheme, p.netloc, quote(unquote(p.path), safe="/"), p.query, p.fragment))
  ```
- **PyMuPDF API**：用 `doc.page_count`（**不是** `doc.pages`，旧版属性在新版已移除）。
- **PaddleOCR 报错 `NotImplementedError: ConvertPirAttribute2RuntimeAttribute`**（oneDNN/PIR bug）：必须 `enable_mkldnn=False`：
  ```python
  OCR_KW = dict(lang="en", ocr_version="PP-OCRv4", enable_mkldnn=False,
                use_doc_orientation_classify=False, use_doc_unwarping=False,
                use_textline_orientation=False, text_det_limit_side_len=1280,
                text_det_limit_type="max", cpu_threads=3)
  ```
- **Excel 32767 字符/单元格硬上限**：openpyxl 超过会**静默截断**（读回正好 32767 就是信号）。关键词串 > 30000 字符时按逗号边界拆成 `keywords` + `keywords_2`（表头动态生成）。校验：读回后逐行 `", ".join(keywords列)` 应与 JSON 完整串**逐字符一致**。
- **pypdf 噪音警告**（`Ignoring wrong pointing object`）：无害，用 `2>/dev/null` 屏蔽，或直接换 PyMuPDF。

## 环境
- **构建/校验脚本**（`parse_all.py` / `build_keywords.py` / 校验）用 **Anaconda** `D:/Programs/anaconda3/python.exe`（自带 `bs4`/`openpyxl`/`fitz`）。
- **OCR 用独立 venv `C:/ocr_env/Scripts/python.exe`**（装 `paddleocr` + `paddlepaddle` + `pymupdf`）。实测 Anaconda base 与 `D:/ocr_env` 装 paddleocr 均被**权限拒绝**（`Permission denied` 写 `Crypto`/`setuptools` 目录），最终 `C:/ocr_env` 成功。若 base 装不上就建 `C:/ocr_env` venv 再 `pip install paddleocr`。
- OCR 单进程较慢：可后台跑（`dangerouslyDisableSandbox: true`，否则首次模型下载/读写 ocr 目录可能被沙箱拦截）；图片型条目直接 `predict(img)` 比 PDF 渲染快很多。
- 网络在中国大陆：给站点镜像/直连自行判断；本任务目标站 elabscience.com 直连可访问。

## 图片型资源处理（与 PDF 的差异）
- 下载：按真实 `ext` 存盘（`.png`/`.jpg`），`localFile` 回写 items.json。
- OCR：`ocr_resource` 按 `ext` 分支——`.pdf` 渲染每页再识别；`.png/.jpg/.jpeg` **直接 `engine().predict(localpath)`**（无需渲染）。输出统一写 `ocr/<localbase>.txt`，`build_keywords` 用 `localFile` 的 base 去 `ocr/` 或 `texts/` 找文本。
- `text_for` 切勿假定 `.pdf` 后缀，必须用 items.json 里的 `localFile` 定位，否则图片条目取不到文本。

## 输出文件约定
- `Flow_Cytometry_Posters_Keywords.xlsx`：表头 `section,title,pdfUrl,keywords[,keywords_2]`。
- `Flow_Cytometry_Posters_Keywords.json`：JSON 数组，每行 `{section,title,pdfUrl,keywords}`，`keywords` 为合并完整串（无 `keywords_2` 残留）。
- 两份文件保持一致；JSON 是送给中台/搜索框的干净源。

## 校验清单
- [ ] 表头含 `section/title/pdfUrl/keywords`（+`keywords_2` 当存在）
- [ ] 数据行 = 实际 PDF 条数，无空 `title`/`url`/`keywords`
- [ ] 最长单元格 < 32767（否则已拆列）
- [ ] JSON 每行 `keywords` 与 Excel 合并后**逐字符一致**
- [ ] 产品 brochure 这类"大册"关键词无截断（最易踩 32767 坑）
- [ ] 关键词无 LLM 碎片脏词（抽查 3~5 行）
