#!/usr/bin/env node
/*
 * pack-skills.mjs —— 把技能目录打成可直接上传的 zip（零第三方依赖）。
 *
 * 为什么不用 PowerShell 的 Compress-Archive：
 *   它依赖 Add-Type（编译并加载 .NET 代码），在受限环境会被安全策略直接拦掉。
 *   这里改用系统自带的 tar（Windows 10+ 的 bsdtar 支持 --format=zip），
 *   一次 spawnSync 调用搞定，无 shell 中转、无编码转换风险。
 *
 * 用法：
 *   node pack-skills.mjs --skill docs-audit-restructure --skill standard-changelog-flow
 *   node pack-skills.mjs --all
 *   node pack-skills.mjs --all --skills-root "D:/x/.workbuddy/skills" --out "D:/x/pkgs"
 *   node pack-skills.mjs --skill <绝对路径> --json
 *
 * 产物：<out>/<skill-name>.zip，zip 内第一层即技能目录名（<name>/SKILL.md）。
 * 退出码：全部成功 = 0；有失败 = 1。
 */
'use strict';

import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';

// ---------------------------------------------------------------- 排除项
// tar 的 --exclude 用 glob，作用于归档内的相对路径。
const EXCLUDES = [
  '*/node_modules',
  '*/node_modules/*',
  '*/.git',
  '*/.git/*',
  '*/dist/*',
  '*/build/*',
  '*/__pycache__/*',
  '*/.venv/*',
  '*/.DS_Store',
  '*/Thumbs.db',
  '*.log',
  '*/.cache/*',
  '*/skill-packages/*',
];

// ---------------------------------------------------------------- 参数
const argv = process.argv.slice(2);
const asJson = argv.includes('--json');
const all = argv.includes('--all');

function valueOf(flag) {
  const i = argv.indexOf(flag);
  return i >= 0 ? argv[i + 1] : undefined;
}
function valuesOf(flag) {
  const out = [];
  argv.forEach((a, i) => {
    if (a === flag && argv[i + 1]) out.push(argv[i + 1]);
  });
  return out;
}

const skillsRoot = path.resolve(
  valueOf('--skills-root') || path.join(os.homedir(), '.workbuddy', 'skills'),
);
const outDir = path.resolve(valueOf('--out') || path.join(os.homedir(), '.workbuddy', 'skill-packages'));

let targets = valuesOf('--skill');
if (all) {
  const found = fs.existsSync(skillsRoot)
    ? fs
        .readdirSync(skillsRoot, { withFileTypes: true })
        .filter((e) => e.isDirectory() && fs.existsSync(path.join(skillsRoot, e.name, 'SKILL.md')))
        .map((e) => e.name)
    : [];
  targets = [...new Set([...targets, ...found])];
}
// 允许传「名字」或「路径」
targets = targets.map((t) => (fs.existsSync(t) ? path.resolve(t) : path.join(skillsRoot, t)));

if (targets.length === 0) {
  console.error('用法: node pack-skills.mjs (--skill <名字|路径> ... | --all) [--skills-root <dir>] [--out <dir>] [--json]');
  process.exit(2);
}

// ---------------------------------------------------------------- tar
/**
 * ⚠️ Windows 上必须显式指定 stdio。
 * spawnSync 默认会「管道化」stdin，本机（以及不少受限/无 TTY 环境）直接返回 **EBUSY**，
 * 表现为「二进制明明存在却说找不到」。故统一 stdio: ['ignore','pipe','pipe']。
 */
const SPAWN_OPTS = { encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] };

function findTar() {
  const candidates = [
    process.env.SystemRoot ? path.join(process.env.SystemRoot, 'System32', 'tar.exe') : null,
    'C:\\Windows\\System32\\tar.exe',
    '/usr/bin/tar',
    'tar',
  ].filter(Boolean);
  for (const c of candidates) {
    const r = spawnSync(c, ['--version'], SPAWN_OPTS);
    if (!r.error && r.status === 0) return c;
  }
  throw new Error('未找到可用的 tar（Windows 需 C:\\Windows\\System32\\tar.exe）');
}
const tarBin = findTar();

// ---------------------------------------------------------------- 主流程
fs.mkdirSync(outDir, { recursive: true });

const results = [];
for (const dir of targets) {
  const name = path.basename(dir);
  const rec = { name, src: dir, zip: path.join(outDir, `${name}.zip`), ok: false, entries: [], bytes: 0, error: null };

  if (!fs.existsSync(path.join(dir, 'SKILL.md'))) {
    rec.error = '缺少 SKILL.md（不是合法技能目录）';
    results.push(rec);
    continue;
  }

  try {
    fs.rmSync(rec.zip, { force: true });
    const args = ['--format=zip', '-cf', rec.zip];
    for (const e of EXCLUDES) args.push(`--exclude=${e}`);
    args.push(name); // 以技能目录名作为顶层
    const r = spawnSync(tarBin, args, { ...SPAWN_OPTS, cwd: path.dirname(dir) });
    if (r.error) throw r.error;
    if (r.status !== 0) throw new Error(`tar 退出码 ${r.status}: ${(r.stderr || '').trim()}`);

    const list = spawnSync(tarBin, ['-tf', rec.zip], SPAWN_OPTS);
    rec.entries = (list.stdout || '').split(/\r?\n/).filter((l) => l && !l.endsWith('/'));
    if (rec.entries.length === 0) throw new Error('zip 内没有任何文件（空包）');
    // 顶层必须是技能目录名
    if (!rec.entries.every((e) => e.startsWith(`${name}/`))) {
      throw new Error(`zip 顶层结构不对（应以 ${name}/ 开头）`);
    }
    rec.bytes = fs.statSync(rec.zip).size;
    rec.ok = true;
  } catch (e) {
    rec.error = e.message;
  }
  results.push(rec);
}

const failed = results.filter((r) => !r.ok);

if (asJson) {
  console.log(JSON.stringify({ outDir, tarBin, results }, null, 2));
} else {
  console.log(`tar: ${tarBin}\n包输出目录: ${outDir}\n`);
  for (const r of results) {
    if (r.ok) {
      console.log(`✓ ${r.name}.zip  (${(r.bytes / 1024).toFixed(1)} KB, ${r.entries.length} 个文件)`);
      for (const e of r.entries) console.log(`    · ${e}`);
    } else {
      console.log(`✗ ${r.name}  失败: ${r.error}`);
    }
  }
  console.log('');
  console.log(`成功 ${results.length - failed.length} / 失败 ${failed.length} / 共 ${results.length}`);
  if (failed.length === 0) {
    console.log('上传发布入口: https://open.workbuddy.cn/skill/all');
  }
}
process.exit(failed.length ? 1 : 0);
